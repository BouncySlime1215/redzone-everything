/* RedZone Everything — phone v2 (flag phone.v2, off by default; server routes in redzone/web/phone_v2.py).
   Why each switch happened (reason chips), 👍/👎 on that one switch, "I missed that", and the Noggin
   Priority L2 sliders. When the flag is off every export here renders "" and nothing else changes. */

import { app, ACTIONS, CHANGES, INPUTS, hooks, attr, esc, num, arr, fmtTime, fmtDur } from "./rz-core.js?v=41";
import { icon, sec } from "./rz-ui.js?v=40";
import { api } from "./rz-api.js?v=43";
import { toast, openSheet, closeSheet, sheetById } from "./rz-sheet.js?v=40";

const v2 = { on: false, checked: false, rows: new Map(), head: "", loading: false, prio: null, missed: null };

let checking = null;
function check() {
  if (!checking) {
    v2.checked = true;
    checking = (async () => {
      try { v2.on = !!(await api("/api/v2/status")).enabled; } catch { v2.on = false; }
      if (v2.on) { hooks.render(); pollAlert(); pollStrip(); pollHeld(); }
    })();
  }
  return checking;
}
check();

/* A your-team crunch clash coming up in the next 30 min: one line above the bar (display only). */
let alert = null;
function pollAlert() {
  api("/api/v2/slate").then((r) => { const a = (r && r.alert) || null; const was = JSON.stringify(alert); alert = a; if (JSON.stringify(a) !== was) hooks.renderScreen("now"); })
    .catch(() => {}).finally(() => setTimeout(pollAlert, 60000));
}
/* Top 3 watch values on the Now screen, refreshed every 15 s (read only; tap for the full sheet). */
let strip = null;
function pollStrip() {
  api("/api/v2/watch").then((r) => {
    const top = arr(r && r.games).slice(0, 3).map((g) => ({ ...g, on: g.game_id === r.current }));
    const next = JSON.stringify({ top, src: r && r.source });
    if (next !== JSON.stringify(strip)) { strip = { top, src: r && r.source }; hooks.renderScreen("now"); }
  }).catch(() => {}).finally(() => setTimeout(pollStrip, 15000));
}
function watchStrip() {
  if (!strip || !strip.top.length) return "";
  return `<button class="v2-strip" data-act="v2-watch" aria-label="Watch value, top 3 live games">${strip.top.map((g) =>
    `<span class="v2-strip-g${g.on ? " on" : ""}"><b>${num(g.wv)}</b><span class="ell"><span class="m">${g.crunch_state ? `<i class="v2-cs v2-cs--${attr(g.crunch_state)}">${esc(CRUNCH_TXT[g.crunch_state])}</i>` : ""}${esc(g.matchup)}</span><small>${esc([g.why, g.stakes_line].filter(Boolean).join(" · "))}</small></span></span>`).join("")}
    ${strip.src === "stub" ? `<em>preview</em>` : ""}</button>`;
}

/* Crunch vs crunch: what the hidden stick holds, how far behind, and what comes back when (display only). */
let heldV = null;
function pollHeld() {
  api("/api/v2/held").then((r) => { const v = (r && r.view) || null; if (JSON.stringify(v) !== JSON.stringify(heldV)) { heldV = v; hooks.renderScreen("now"); } })
    .catch(() => {}).finally(() => setTimeout(pollHeld, 10000));
}
function heldLine() {
  const v = heldV;
  if (!v || (!v.held && !v.back && !v.catchup)) return "";
  const rows = [];
  if (v.held) rows.push(`<span><b>Holding</b> ${esc(v.held.matchup)}${v.held.behind_s ? ` · ${esc(fmtDur(v.held.behind_s))} behind live` : ""}${v.held.ready ? "" : " · loading"}</span>`);
  if (v.back) rows.push(`<span><b>Coming back</b> ${esc(v.back.text)}</span>`);
  if (v.catchup) rows.push(`<span><b>Next catch-up</b> ${esc(v.catchup.matchup)}: ${esc(v.catchup.label || v.catchup.kind)}${v.queued > 1 ? ` (+${num(v.queued - 1)} more)` : ""}</span>`);
  return `<div class="v2-held" data-key="v2-held">${icon("hourglass")}<div>${rows.join("")}</div></div>`;
}

function alertLine() {
  if (!alert) return "";
  const when = alert.now ? "Now" : alert.in_s < 90 ? "In a minute" : `In ${Math.round(alert.in_s / 60)} min`;
  return `<button class="v2-alert" data-act="v2-slate">${icon("alert")}<span><b>${esc(when)}: crunch times overlap.</b> ${esc(alert.on_tv)} gets the TV (${esc(alert.why)}); ${esc(arr(alert.second).join(", "))} on the second stick.</span></button>`;
}

/** Refetch chips + votes when the newest switch changes. */
function sync(S) {
  const log = arr(S && S.log);
  const head = log.length ? `${log[0].ts}|${log[0].to}` : "";
  if (!v2.on || v2.loading || head === v2.head) return;
  v2.loading = true;
  api("/api/v2/switches").then((r) => {
    v2.rows = new Map(arr(r && r.switches).map((x) => [`${x.ts}|${x.to}`, x]));
    v2.head = head;
  }).catch(() => {}).finally(() => { v2.loading = false; hooks.renderScreen("now"); });
}

export const v2On = () => v2.on;

/** Extra line under one "Recent switches" row: reason chips + 👍/👎. */
export function switchExtras(l) {
  if (!v2.on) return "";
  sync(app.S);
  const r = v2.rows.get(`${l.ts}|${l.to}`);
  if (!r) return "";
  const vb = (v, ic, label) => `<button class="v2-vote ${r.vote === v ? "on" : ""}" data-act="v2-vote" data-key="${attr(r.key)}" data-v="${r.vote === v ? 0 : v}"
    aria-pressed="${r.vote === v}" aria-label="${attr(label)}">${icon(ic)}</button>`;
  return `<div class="v2-why">${arr(r.chips).map((c) => `<span class="v2-chip v2-chip--${attr(c.key)}">${esc(c.label)}</span>`).join("")}
    <span class="grow"></span>${vb(1, "thumb-up", "Good switch")}${vb(-1, "thumb-down", "Bad switch")}</div>`;
}

ACTIONS["v2-vote"] = async (el) => {
  const key = el.dataset.key, vote = num(el.dataset.v);
  try {
    const r = await api("/api/v2/vote", { body: { key, vote } });
    if (r.ok) { for (const x of v2.rows.values()) if (x.key === key) x.vote = vote; }
    toast(r.message, r.ok ? "ok" : "warn");
  } catch (err) { toast(err.message || "That didn't work", "error"); }
  hooks.renderScreen("now");
};

/** The "I missed that" bar above Recent switches. */
export function missedBar() {
  if (!v2.on) return "";
  return `${alertLine()}${heldLine()}${watchStrip()}<div class="v2-bar" data-key="v2-bar"><button class="btn v2-missed" data-act="v2-missed">${icon("eye")}I missed that</button>
    <button class="btn btn--ghost" data-act="v2-night">${icon("replay")}Whole night</button>
    <button class="btn btn--ghost v2-span" data-act="v2-slate">${icon("calendar")}Tonight ahead: overlaps and crunch times</button>
    <button class="btn btn--ghost v2-span" data-act="v2-watch">${icon("flame")}Watch value: every live game, 0-100, and why</button>
    <button class="btn btn--ghost v2-span" data-act="v2-trend">${icon("trend")}How close to perfect: North Star trend</button>
    <button class="btn btn--ghost v2-span" data-act="v2-capture">${icon("moon")}Live night: did it become gold data?</button>
    <button class="btn btn--ghost v2-span" data-act="v2-ledger">${icon("activity")}Data + NFM: what the Noggin learns from</button></div>`;
}

function missedSheet() {
  const m = v2.missed || {};
  const c = arr(m.candidates);
  return `<h3>Which play?</h3><p class="lead">${esc(m.message, "")}</p>
    <div class="pick-list" style="margin-top:12px">${c.map((x) => `<button class="pick" data-act="v2-missed-pick" data-gid="${attr(x.game_id)}" aria-pressed="${!!m.guess && m.guess.game_id === x.game_id}">
      <span class="grow"><span class="t1" style="display:block">${esc(x.matchup)}</span><span class="t2 ell" style="display:block">${esc(x.text || x.kind)} · ${Math.round(num(x.ago_s) / 60)} min ago</span></span>
      <span class="tick">${icon("check")}</span></button>`).join("")}</div>`;
}

ACTIONS["v2-missed"] = async (el) => {
  el.setAttribute("aria-busy", "true");
  try {
    const r = await api("/api/v2/missed", { body: {} });
    v2.missed = r;
    if (arr(r.candidates).length > 1) openSheet({ id: "v2-missed", label: "Which play", render: missedSheet });
    else toast(r.message, "ok");
  } catch (err) { toast(err.message || "That didn't work", "error"); }
  finally { el.removeAttribute("aria-busy"); }
};
ACTIONS["v2-missed-pick"] = async (el) => {
  try {
    const r = await api("/api/v2/missed", { body: { game_id: el.dataset.gid } });
    toast(r.message, "ok");
  } catch (err) { toast(err.message || "That didn't work", "error"); }
  closeSheet(sheetById("v2-missed"));
};

/* ---------- Settings: Noggin Priority L2 ---------- */
const SLIDERS = [
  ["bets_weight", "Your bets", "How much a live bet pulls the TV toward its game", 0.1],
  ["rivalry_points", "Rivalries", "Points a rivalry game gets on top of its live value", 1],
  ["nhl_pp_ot_boost", "NHL power plays + OT", "Extra pull for power plays and overtime", 0.1],
  ["switch_frequency", "Switch how often", "Calmer stays put longer; busier chases more", 0.1],
];

function loadPrio() {
  if (v2.prio || !v2.on) return;
  v2.prio = { loading: true };
  api("/api/v2/priority").then((r) => { v2.prio = r; }).catch((e) => { v2.prio = { error: e.message }; })
    .finally(() => hooks.renderScreen("settings"));
}

export function prioritySection() {
  if (!v2.on) return "";
  loadPrio();
  const p = v2.prio || {};
  const head = sec("Your priorities", { key: "s-v2prio", aside: "Never beats your hard rules" });
  if (!p.prefs) return `${head}<div class="card card-pad" data-key="v2prio"><div class="t2">${p.error ? esc(p.error) : "Loading…"}</div></div>`;
  const rows = SLIDERS.map(([k, label, help, step]) => {
    const [lo, hi] = arr(p.ranges && p.ranges[k]).length ? p.ranges[k] : [0, 2];
    const v = num(p.prefs[k], lo);
    const pct = ((v - lo) / Math.max(1e-9, hi - lo)) * 100;
    return `<div class="slider"><div class="slider-top"><span class="t1">${esc(label)}</span><span class="val tnum" data-v2-val="${attr(k)}">${esc(v)}</span></div>
      <div class="t2">${esc(help)}</div>
      <input class="range" type="range" min="${lo}" max="${hi}" step="${step}" value="${v}" style="--p:${pct.toFixed(1)}" data-sync data-input="v2-prio" data-k="${attr(k)}" aria-label="${attr(label)}"></div>`;
  }).join("");
  const reels = `<div class="set-r"><div class="grow"><div class="t1">Catch-up reels</div><div class="t2">Short reels of plays you missed, only in dead time</div></div>
    <label class="switch"><input type="checkbox" data-change="v2-reels" ${p.prefs.reels ? "checked" : ""} aria-label="Catch-up reels"><span></span></label></div>`;
  const sugg = arr(p.suggestions);
  const learned = `<div class="t2" style="margin-top:10px">${sugg.length
    ? `From your ${p.votes} ratings: ${sugg.map((s) => `${esc(s.suggest === "less" ? "less" : "more")} <b>${esc(s.term)}</b>`).join(", ")}. Suggestions only; nothing changes until you move a slider.`
    : `Your sliders are the only way these change; the Noggin teaches itself and never learns from your ratings.`}</div>`;
  return `${head}<div class="card set" data-key="v2prio">${rows}${reels}<div class="card-pad">${learned}</div></div>`;
}

async function savePrio(changes) {
  try {
    const r = await api("/api/v2/priority", { body: changes });
    if (r.ok && v2.prio && v2.prio.prefs) Object.assign(v2.prio.prefs, r.prefs);
    toast(r.message, r.ok ? "ok" : "warn");
  } catch (err) { toast(err.message || "That didn't work", "error"); }
}

INPUTS["v2-prio"] = (el) => {
  const v = Number(el.value), k = el.dataset.k;
  const lbl = document.querySelector(`[data-v2-val="${CSS.escape(k)}"]`);
  if (lbl) lbl.textContent = v;
  el.style.setProperty("--p", (((v - +el.min) / Math.max(1e-9, +el.max - +el.min)) * 100).toFixed(1));
  clearTimeout(INPUTS["v2-prio"].t);
  INPUTS["v2-prio"].t = setTimeout(() => savePrio({ [k]: v }), 400);
};

CHANGES["v2-reels"] = (el) => savePrio({ reels: !!el.checked });

/* ---------- Night replay viewer: what was on, every switch, hold and tap, with playbook ids ---------- */
const PAL = 8;   // segment colors cycle through .v2-c0 .. .v2-c7 (app.css)
const night = { day: "", data: null, loading: false, filter: "all", at: null };   // at: epoch s to highlight (a deep link)

function colorOf(matchup, order) {
  let i = order.indexOf(matchup);
  if (i < 0) { order.push(matchup); i = order.length - 1; }
  return i % PAL;
}

async function loadNight(day = "") {
  night.loading = true;
  try { night.data = await api(`/api/v2/night${day ? `?day=${encodeURIComponent(day)}` : ""}`); night.day = night.data.day || day; }
  catch (e) { night.data = { error: e.message }; }
  finally { night.loading = false; const s = sheetById("v2-night"); if (s) s.update(); }
}

const EV_IC = { switch: "swap", decision: "hourglass", tap: "thumb-up" };
const TAP_IC = { up: "thumb-up", down: "thumb-down", missed: "eye", clear: "x" };
const TAP_TXT = { up: "You rated it good", down: "You rated it bad", missed: "You missed a play", clear: "Rating cleared" };

function nightSheet() {
  const d = night.data;
  if (!d) return `<h3>The whole night</h3><p class="lead">Loading…</p>`;
  if (d.error) return `<h3>The whole night</h3><p class="lead">${esc(d.error)}</p>`;
  const sm = d.summary || {};
  const taps = sm.taps || {};
  const order = arr(sm.on_air).map((r) => r.matchup);
  const segs = arr(d.segments);
  const days = arr(d.nights).map((x) => `<button class="v2-day" data-act="v2-night-day" data-day="${attr(x)}" aria-pressed="${x === d.day}">${esc(
    new Date(x + "T12:00:00").toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" }))}</button>`).join("");
  let ribbon = `<div class="t2" style="margin:10px 0">No switches this night.</div>`;
  if (segs.length) {
    const a = segs[0].t0, b = Math.max(segs[segs.length - 1].t1, a + 60), span = b - a;
    const ticks = [];
    const first = Math.ceil(a / 3600) * 3600;
    for (let t = first; t < b; t += 3600) ticks.push(`<i style="left:${(((t - a) / span) * 100).toFixed(2)}%"><span>${esc(fmtTime(t).replace(":00", ""))}</span></i>`);
    const bars = (list) => list.filter((sg) => sg.t1 > a && sg.t0 < b).map((sg) =>
      `<b class="v2-c${colorOf(sg.matchup, order)}" style="left:${(((Math.max(sg.t0, a) - a) / span) * 100).toFixed(2)}%;width:${Math.max(0.4, ((Math.min(sg.t1, b) - Math.max(sg.t0, a)) / span) * 100).toFixed(2)}%" title="${attr(sg.matchup)} ${attr(fmtTime(sg.t0))}"></b>`).join("");
    const marks = arr(d.markers).filter((m) => m.ts >= a && m.ts < b).map((m) =>
      `<em class="v2-mark${m.seen ? "" : " v2-mark--miss"}" style="left:${(((m.ts - a) / span) * 100).toFixed(2)}%" title="${attr(`${m.seen ? "Seen live" : "Missed"}: ${m.matchup} ${m.kind} ${fmtTime(m.ts)}`)}"></em>`).join("");
    const pm = arr(d.plan_marks).filter((m) => m.ts >= a && m.ts < b);
    const lane = pm.length ? `<div class="v2-rlabel">What the planner chose: <span class="v2-pm-key v2-pm--catchup">▲</span> catch-up <span class="v2-pm-key v2-pm--interleave">◆</span> break visit / return</div>
      <div class="v2-pmlane" role="img" aria-label="${attr(`${num((d.plan_counts || {}).catchup)} catch-ups and ${num((d.plan_counts || {}).interleave)} break visits`)}">${pm.map((m) =>
        `<i class="v2-pm v2-pm--${attr(m.type)}${m.ok ? "" : " v2-pm--fail"}" style="left:${(((m.ts - a) / span) * 100).toFixed(2)}%" title="${attr(`${m.type === "catchup" ? "Catch-up" : m.kind === "return" ? "Back home" : "Break visit"}: ${m.matchup} ${fmtTime(m.ts)}${m.plan ? " (plan " + m.plan + ")" : ""}`)}">${m.type === "catchup" ? "▲" : "◆"}</i>`).join("")}</div>` : "";
    const o = d.oracle, cr = d.crunch || {};
    const X = (t) => (((Math.max(a, Math.min(b, t)) - a) / span) * 100).toFixed(2);
    const spanBars = (list, cls) => arr(list).filter(([t0, t1]) => t1 > a && t0 < b).map(([t0, t1]) =>
      `<b class="${cls}" style="left:${X(t0)}%;width:${Math.max(0.4, X(t1) - X(t0)).toFixed(2)}%"></b>`).join("");
    const dlt = (s) => (typeof s === "number" ? `${s > 0 ? "+" : ""}${Math.round(s)} s` : "–");
    const crunchRows = arr(cr.games).map((g) => `<div class="v2-cr">
        <div class="v2-cr-top"><span class="m">${esc(g.matchup)}</span>${"exit_ok" in g ? `<span class="tag tag--${g.exit_ok ? "pass" : "fail"}">exit ${esc(dlt(g.exit_s))}</span>
          <span class="tag tag--${g.entry_ok ? "pass" : "fail"}">entry ${esc(dlt(g.entry_s))}</span>` : ""}</div>
        <div class="v2-cr-track" title="Learned">${spanBars(g.learned, "v2-cr-l")}${arr(g.points).map((p) => `<i class="v2-cs--${attr(p.state)}" style="left:${X(p.ts)}%" title="${attr(`${CRUNCH_TXT[p.state] || p.state} ${fmtTime(p.ts)}`)}"></i>`).join("")}</div>
        <div class="v2-cr-track v2-cr-track--o" title="Hindsight">${spanBars(g.oracle, "v2-cr-o")}</div></div>`).join("");
    const crunchBox = cr.source ? `<div class="v2-rlabel">Crunch: learned (top) vs hindsight (bottom)${cr.source === "graded"
      ? ` · exits right ${num(cr.exits_ok)}/${num(cr.exits)} (within ${num(cr.tol_s)} s)` : " · hindsight pending: learned states from switch traces"}</div><div class="v2-crs">${crunchRows}</div>` : "";
    ribbon = `<div class="v2-ribbon" role="img" aria-label="What was on the TV, ${esc(fmtTime(a))} to ${esc(fmtTime(b))}">${bars(segs)}${marks}</div>
      ${lane}
      ${o ? `<div class="v2-rlabel">Best possible (hindsight)${o.agree_pct != null ? ` · we matched ${esc(String(o.agree_pct))}% of the time` : ""}</div>
      <div class="v2-ribbon v2-ribbon--oracle" role="img" aria-label="What the hindsight oracle would have shown">${bars(arr(o.segments))}</div>` : ""}
      <div class="v2-ticks">${ticks.join("")}</div>
      ${crunchBox}
      <div class="v2-legend">${arr(sm.on_air).map((r) => `<span><i class="v2-c${colorOf(r.matchup, order)}"></i>${esc(r.matchup)} <small>${esc(fmtDur(r.s))}</small></span>`).join("")}</div>`;
  }
  const pb = Object.entries(sm.playbooks || {});
  const F = [["all", "All"], ["switch", "Switches"], ["decision", "Holds"], ["tap", "Your taps"]];
  const evs = arr(d.events).filter((e) => night.filter === "all" || e.type === night.filter).slice().reverse();
  const row = (e) => {
    const ic = e.type === "tap" ? TAP_IC[e.kind] || "thumb-up" : EV_IC[e.type] || "tv";
    const title = e.type === "tap" ? TAP_TXT[e.kind] || "Tap" : e.type === "decision" ? `${e.kind === "wait" ? "Waited" : "Held"}${e.matchup ? " on " + e.matchup : ""}` : e.matchup;
    const tags = [
      ...arr(e.chips).map((c) => `<span class="v2-chip v2-chip--${attr(c.key)}">${esc(c.label)}</span>`),
      ...arr(e.playbooks).map((p) => `<span class="tag tag--kind">${esc(p)}</span>`),
      e.type === "switch" && e.dry_run ? `<span class="tag tag--would">Would switch</span>` : "",
      e.type === "switch" && !e.ok && !e.dry_run ? `<span class="tag tag--fail">Failed</span>` : "",
      e.type === "switch" && e.key ? `<button class="v2-trace-btn" data-act="v2-prov" data-key="${attr(e.key)}">${icon("activity")}Trace</button>` : "",
    ].join("");
    const hit = night.at && Math.abs(num(e.ts) - night.at) <= 120 ? " v2-ev--hit" : "";
    return `<div class="v2-ev v2-ev--${attr(e.type)}${hit}"><span class="v2-ev-ic">${icon(ic)}</span><div style="min-width:0">
      <div class="v2-ev-top"><span class="m ell">${esc(title)}</span><span class="t">${esc(fmtTime(e.ts))}</span></div>
      ${e.reason ? `<div class="v2-ev-why">${esc(String(e.reason).replace(/\s*playbook=\S+/g, ""))}</div>` : ""}${tags ? `<div class="v2-why">${tags}</div>` : ""}</div></div>`;
  };
  return `<h3>The whole night</h3>
    <div class="v2-days">${days}</div>
    <div class="v2-tiles"><div class="stile"><b>${num(sm.switches)}</b><span>Switches</span></div>
      <div class="stile"><b>${num(sm.games)}</b><span>Games shown</span></div>
      <div class="stile"><b>${num(taps.up)}/${num(taps.down)}</b><span>👍 / 👎</span></div>
      <div class="stile"><b>${num(taps.missed)}</b><span>Missed</span></div>
      ${d.big && d.big.plays ? `<div class="stile"><b>${num(d.big.seen)}/${num(d.big.plays)}</b><span>Big plays live</span></div>` : ""}</div>
    <div class="sheet-sec"><h4>What was on</h4>${sm.failed ? `<small>${num(sm.failed)} failed</small>` : ""}</div>${ribbon}
    ${pb.length ? `<div class="sheet-sec"><h4>Playbooks used</h4></div><div class="v2-why">${pb.map(([k, n]) => `<span class="tag tag--kind">${esc(k)} × ${num(n)}</span>`).join("")}</div>` : ""}
    <div class="sheet-sec"><h4>Timeline</h4><small>newest first</small></div>
    <div class="v2-days">${F.map(([k, l]) => `<button class="v2-day" data-act="v2-night-filter" data-f="${k}" aria-pressed="${night.filter === k}">${l}</button>`).join("")}</div>
    <div class="v2-evs">${evs.length ? evs.map(row).join("") : `<div class="t2">Nothing here.</div>`}</div>`;
}

ACTIONS["v2-night"] = () => { night.data = null; night.at = null; openSheet({ id: "v2-night", label: "The whole night", full: true, render: nightSheet }); loadNight(""); };
ACTIONS["v2-night-day"] = (el) => { night.data = null; const s = sheetById("v2-night"); if (s) s.update(); loadNight(el.dataset.day); };
/* Deep link from the night health report (scripts/night_report.py): #night=YYYY-MM-DD&at=HH:MM (ET; a time
   before noon is after midnight, the same night) opens the whole night on that day, the miss highlighted. */
export function nightFromHash(hash = (typeof location !== "undefined" ? location.hash : "")) {
  const m = /^#night=(\d{4}-\d{2}-\d{2})(?:&at=(\d{2}):(\d{2}))?$/.exec(hash || "");
  if (!m) return null;
  let at = null;
  if (m[2]) {
    const d = new Date(`${m[1]}T${m[2]}:${m[3]}:00`);
    if (+m[2] < 12) d.setDate(d.getDate() + 1);
    at = d.getTime() / 1000;
  }
  return { day: m[1], at };
}
async function openNightLink() {
  const l = nightFromHash();
  if (!l) return;
  await check();
  if (!v2.on) return;   // the viewer is phone v2 (flag phone.v2)
  night.data = null; night.filter = "all"; night.at = l.at;
  openSheet({ id: "v2-night", label: "The whole night", full: true, render: nightSheet });
  loadNight(l.day).then(() => { try { document.querySelector(".v2-ev--hit")?.scrollIntoView({ block: "center" }); } catch { /* no DOM */ } });
}
try { if (typeof window !== "undefined") { window.addEventListener("hashchange", openNightLink); setTimeout(openNightLink, 0); } } catch { /* no DOM */ }
ACTIONS["v2-night-filter"] = (el) => { night.filter = el.dataset.f; const s = sheetById("v2-night"); if (s) s.update(); };

/* ---------- Watch value: each live game's 0-100 and its one-line why (read only) ---------- */
const watchS = { data: null, timer: null };
async function loadWatch() {
  try { watchS.data = await api("/api/v2/watch"); } catch (e) { watchS.data = { error: e.message }; }
  const s = sheetById("v2-watch");
  if (s) { s.update(); clearTimeout(watchS.timer); watchS.timer = setTimeout(loadWatch, 10000); }
}
const CRUNCH_TXT = { entering: "Crunch soon", in: "Crunch", leaving: "Crunch ending" };
function watchSheet() {
  const d = watchS.data;
  if (!d) return `<h3>Watch value</h3><p class="lead">Loading…</p>`;
  if (d.error) return `<h3>Watch value</h3><p class="lead">${esc(d.error)}</p>`;
  const gs = arr(d.games);
  if (!gs.length) return `<h3>Watch value</h3><p class="lead">No live games right now.</p>`;
  const note = d.source === "learned" ? "The Noggin's learned watch value, updated every few seconds."
    : "Preview: today's priority score until the learned watch value ships.";
  return `<h3>Watch value</h3><p class="lead">${esc(note)}</p>
    <div class="v2-wv">${gs.map((g) => `<div class="v2-wv-row${g.game_id === d.current ? " on" : ""}">
      <div class="v2-wv-top"><span class="m ell">${esc(g.matchup)}</span>${g.game_id === d.current ? `<span class="tag tag--kind">On TV</span>` : ""}${g.crunch_state ? `<span class="tag tag--fail">${esc(CRUNCH_TXT[g.crunch_state] || "Crunch")}</span>` : ""}${g.is_break ? `<span class="tag">Break</span>` : ""}<b>${num(g.wv)}</b></div>
      <div class="v2-wv-bar"><i style="width:${Math.max(2, Math.min(100, g.wv))}%"></i></div>
      ${g.why ? `<div class="v2-ev-why">${esc(g.why)}</div>` : ""}${g.stakes_line || g.stakes_pending ? `<div class="v2-stakes${g.stakes_pending ? " v2-stakes--pending" : ""}">${icon("target")}${esc(g.stakes_line || "Stakes")}${g.stakes_pending ? " <small>(model pending)</small>" : ""}</div>` : ""}</div>`).join("")}</div>`;
}
ACTIONS["v2-watch"] = () => { watchS.data = null; openSheet({ id: "v2-watch", label: "Watch value", full: true, render: watchSheet, onClose: () => clearTimeout(watchS.timer) }); loadWatch(); };

/* ---------- Provenance: which module contributed what to one switch (from its trace) ---------- */
const prov = { data: null };
const STAGE_TXT = { decided: "Decided", guarded: "Guard checked", rechecked: "Re-checked", command: "Command sent", picture: "Picture on TV", aborted: "Held back", failed: "Failed" };
const MOD_TXT = { watch_value: "Watch value", crunch_state: "Crunch state", importance: "Importance", stakes: "Stakes", floors: "Floors", planner: "Planner", playbook: "Playbook", guard: "Guard", control: "Control", decider: "Decider", sync: "Sync (delays)" };
const short = (v) => (v == null ? "–" : typeof v === "object" ? Object.entries(Array.isArray(v) ? { ...v } : v).filter(([, x]) => x != null && x !== "")
  .map(([k, x]) => (Array.isArray(v) ? String(typeof x === "object" ? JSON.stringify(x) : x) : `${k}: ${typeof x === "object" ? JSON.stringify(x) : x}`)).join(" · ") : String(v));
function provSheet() {
  const d = prov.data;
  if (!d) return `<h3>Switch trace</h3><p class="lead">Loading…</p>`;
  if (d.error || d.ok === false) return `<h3>Switch trace</h3><p class="lead">${esc(d.error || d.message || "Not found")}</p>`;
  const t0 = arr(d.chain).length ? d.chain[0].at : d.ts;
  return `<h3>Switch trace</h3>
    <p class="lead">${esc(d.from ? `${d.from} → ${d.to}` : d.to)} · ${esc(fmtTime(d.ts))}${d.source === "stub" ? " · rebuilt from the switch log (no provenance fields yet)" : ""}</p>
    <div class="v2-why">${arr(d.chips).map((c) => `<span class="v2-chip v2-chip--${attr(c.key)}">${esc(c.label)}</span>`).join("")}</div>
    <div class="sheet-sec"><h4>Who contributed</h4></div>
    <div class="v2-prov">${arr(d.parts).map((p) => `<div class="v2-prov-row"><b>${esc(MOD_TXT[p.module] || p.module)}</b><span>${esc(short(p.value))}</span></div>`).join("")}</div>
    <div class="sheet-sec"><h4>Timeline</h4>${d.has_trace ? "" : "<small>no trace stored</small>"}</div>
    <div class="v2-prov">${arr(d.chain).map((c) => `<div class="v2-prov-row"><b>${esc(STAGE_TXT[c.stage] || c.stage)} <small>+${(c.at - t0).toFixed(1)} s</small></b><span>${esc(c.component)}${Object.keys(c.detail || {}).length ? " · " + esc(short(c.detail)) : ""}</span></div>`).join("")}</div>`;
}
ACTIONS["v2-prov"] = async (el) => {
  prov.data = null; openSheet({ id: "v2-prov", label: "Switch trace", full: true, render: provSheet });
  try { prov.data = await api(`/api/v2/provenance?key=${encodeURIComponent(el.dataset.key)}`); } catch (e) { prov.data = { error: e.message }; }
  const s = sheetById("v2-prov"); if (s) s.update();
};

/* ---------- North Star trend: each headline line over the harness runs, read-only ---------- */
const trendS = { data: null, split: "dev" };
async function loadTrend() {
  try { trendS.data = await api(`/api/v2/trend?split=${trendS.split}`); } catch (e) { trendS.data = { error: e.message }; }
  const s = sheetById("v2-trend"); if (s) s.update();
}
const STAT = { PASS: "pass", FAIL: "fail" };
function spark(l) {
  const pts = arr(l.points).map((p, i) => [i, p.v]).filter(([, v]) => typeof v === "number");
  if (!pts.length) return `<svg class="v2-spark" viewBox="0 0 100 28"></svg>`;
  const vs = pts.map(([, v]) => v).concat(l.bar), lo = Math.min(...vs), hi = Math.max(...vs), n = Math.max(1, arr(l.points).length - 1);
  const y = (v) => (hi === lo ? 14 : 25 - ((v - lo) / (hi - lo)) * 22).toFixed(1), x = (i) => ((i / n) * 100).toFixed(1);
  return `<svg class="v2-spark" viewBox="0 0 100 28" preserveAspectRatio="none" aria-hidden="true">
    <line x1="0" x2="100" y1="${y(l.bar)}" y2="${y(l.bar)}" class="v2-spark-bar"/>
    <polyline points="${pts.map(([i, v]) => `${x(i)},${y(v)}`).join(" ")}" class="v2-spark-line"/>
    <circle cx="${x(pts[pts.length - 1][0])}" cy="${y(pts[pts.length - 1][1])}" r="2.2" class="v2-spark-dot"/></svg>`;
}
function trendSheet() {
  const d = trendS.data;
  if (!d) return `<h3>How close to perfect</h3><p class="lead">Loading…</p>`;
  if (d.error) return `<h3>How close to perfect</h3><p class="lead">${esc(d.error)}</p>`;
  const tabs = [["dev", "Dev nights"], ["locked", "Locked test nights"]].map(([k, l]) =>
    `<button class="v2-day" data-act="v2-trend-split" data-f="${k}" aria-pressed="${trendS.split === k}">${l}</button>`).join("");
  if (!d.runs) return `<h3>How close to perfect</h3><div class="v2-days">${tabs}</div><p class="lead">No North Star runs yet.</p>`;
  const fmt = (v) => (typeof v === "number" ? (Math.abs(v) >= 10 ? v.toFixed(1) : v.toFixed(2)).replace(/\.0+$/, "") : "–");
  const rows = arr(d.lines).map((l) => `<div class="v2-trend">
      <div class="v2-trend-top"><span class="m">${esc(l.label)}</span><span class="tag tag--${STAT[l.status] || "kind"}">${esc(l.status || "–")}</span></div>
      <div class="v2-trend-mid">${spark(l)}<div class="v2-trend-num"><b>${fmt(l.latest)}</b><small>bar ${fmt(l.bar)}${l.gap ? ` · ${fmt(l.gap)} to go` : ""}</small>
      ${typeof l.better === "number" && l.better !== 0 ? `<small class="${l.better > 0 ? "up" : "down"}">${l.better > 0 ? "▲" : "▼"} ${fmt(Math.abs(l.better))} since first run</small>` : ""}</div></div></div>`).join("");
  return `<h3>How close to perfect</h3>
    <div class="v2-days">${tabs}</div>
    <div class="v2-tiles"><div class="stile"><b>${num(d.passing)}/${num(arr(d.lines).length)}</b><span>Lines passing</span></div>
      <div class="stile"><b>${num(d.runs)}</b><span>Runs</span></div>
      <div class="stile"><b>${esc(String(d.commit || "–"))}</b><span>${esc(String(d.ts || ""))}</span></div></div>
    <div class="v2-trends">${rows}</div>`;
}
ACTIONS["v2-trend"] = () => { trendS.data = null; openSheet({ id: "v2-trend", label: "How close to perfect", full: true, render: trendSheet }); loadTrend(); };
ACTIONS["v2-trend-split"] = (el) => { trendS.split = el.dataset.f; trendS.data = null; const s = sheetById("v2-trend"); if (s) s.update(); loadTrend(); };

/* ---------- Live night: the morning check that last night became gold data (auto-log, provenance, held, report) ---------- */
const cap = { data: null, day: "", report: null };
const shiftDay = (d, n) => { const t = new Date(`${d}T12:00:00Z`); t.setUTCDate(t.getUTCDate() + n); return t.toISOString().slice(0, 10); };
async function loadCapture() {
  try { cap.data = await api(`/api/v2/capture${cap.day ? `?day=${cap.day}` : ""}`); if (cap.data && cap.data.night) cap.day = cap.data.night; } catch (e) { cap.data = { error: e.message }; }
  const s = sheetById("v2-capture"); if (s) s.update();
}
function captureSheet() {
  const d = cap.data;
  if (!d) return `<h3>Live night</h3><p class="lead">Loading…</p>`;
  if (d.error || d.ok === false) return `<h3>Live night</h3><p class="lead">${esc(d.error || d.message)}</p>`;
  if (cap.report != null) return `<h3>Night report · ${esc(d.night)}</h3><button class="v2-day" data-act="v2-capture-back">Back</button><pre class="v2-report">${esc(cap.report)}</pre>`;
  const nav = `<div class="v2-days"><button class="v2-day" data-act="v2-capture-day" data-n="-1">◀ ${esc(shiftDay(d.night, -1))}</button>
    <button class="v2-day" aria-pressed="true">${esc(d.night)}</button><button class="v2-day" data-act="v2-capture-day" data-n="1">${esc(shiftDay(d.night, 1))} ▶</button></div>`;
  const checks = arr(d.checks).map((c) => `<div class="v2-ms"><span class="tag tag--${c.ok ? "pass" : "fail"}">${c.ok ? "yes" : "no"}</span><span>${esc(c.label)}</span></div>`).join("");
  const a = d.autolog, kv = (k, v) => `<span><b>${v == null ? "–" : esc(String(v))}</b> ${esc(k)}</span>`;
  const auto = a ? `<div class="v2-led"><div class="v2-led-nums">${kv("cuts graded", a.cuts_graded)}${kv("mid-play entries", a.entries_mid_play)}${kv("switch p95 s", a.switch_p95_s)}${kv("picture ≤ 3 s", a.picture_within_3s)}${kv("press→TV p95 s", a.press_to_tv_p95_s)}${kv("mid-play leaves", a.leaves_mid_play)}</div>
      <small>${Object.entries(a.rows || {}).map(([k, n]) => `${esc(k)} ${num(n)}`).join(" · ")}</small></div>` : `<p class="lead">No auto-log yet: the supervisor collects it after 6 AM ET.</p>`;
  const prov = arr(d.provenance_keys).length ? arr(d.provenance_keys).map((p) => `<span class="chip">${esc(MOD_TXT[p.module] || p.module)} ${num(p.n)}</span>`).join(" ") : `<span class="m">No provenance yet (lane 3's traces).</span>`;
  const h = d.held || {}, now = Object.entries(h.now || {}), log = Object.entries(h.log || {});
  return `<h3>Live night</h3>${nav}
    <div class="v2-tiles"><div class="stile"><b>${d.gold ? "Gold" : "Not yet"}</b><span>All checks</span></div>
      <div class="stile"><b>${num(d.with_provenance)}/${num(d.switches)}</b><span>Switches with provenance</span></div>
      <div class="stile"><b>${num(d.with_trace)}</b><span>With a trace</span></div></div>
    <div class="v2-mss">${checks}</div>
    <h4>Auto-log</h4>${auto}
    <h4>Who spoke (provenance)</h4><div class="v2-chips">${prov}</div>
    <h4>Held buffer</h4><p class="lead">${now.length ? now.map(([t, s]) => `${esc(t)} held ${num(s)} s behind live.`).join(" ") : "Nothing held right now."}${log.length ? ` Log: ${log.map(([k, n]) => `${esc(k)} ${num(n)}`).join(", ")}.` : ""}</p>
    ${d.report ? `<button class="btn btn--ghost" data-act="v2-capture-report">${icon("replay")}Open the night report</button>` : `<p class="lead">No night report for this night.</p>`}`;
}
ACTIONS["v2-capture"] = () => { cap.data = null; cap.day = ""; cap.report = null; openSheet({ id: "v2-capture", label: "Live night", full: true, render: captureSheet }); loadCapture(); };
ACTIONS["v2-capture-day"] = (el) => { cap.day = shiftDay(cap.day, Number(el.dataset.n)); cap.data = null; cap.report = null; const s = sheetById("v2-capture"); if (s) s.update(); loadCapture(); };
ACTIONS["v2-capture-report"] = async () => {
  try { const r = await api(`/api/v2/capture/report?day=${cap.day}`); cap.report = r.text || "(empty)"; } catch (e) { cap.report = e.message; }
  const s = sheetById("v2-capture"); if (s) s.update();
};
ACTIONS["v2-capture-back"] = () => { cap.report = null; const s = sheetById("v2-capture"); if (s) s.update(); };

/* ---------- Data ledger + NFM status: tokens per league, real vs synthetic, and the model's milestones ---------- */
const ledgerS = { data: null };
const MS_TAG = { done: "pass", running: "kind", next: "kind", blocked: "fail" };
function ledgerSheet() {
  const d = ledgerS.data;
  if (!d) return `<h3>Data + NFM</h3><p class="lead">Loading…</p>`;
  if (d.error) return `<h3>Data + NFM</h3><p class="lead">${esc(d.error)}</p>`;
  const big = (v) => (typeof v !== "number" ? "PENDING" : v >= 1e9 ? `${(v / 1e9).toFixed(2)}B` : v >= 1e5 ? `${(v / 1e6).toFixed(1)}M` : Math.round(v).toLocaleString());
  const pct = (v) => (typeof v === "number" ? `${Math.round(v * 100)}%` : "–");
  const t = d.totals || {}, nfm = d.nfm || {};
  const rows = arr(d.rows).filter((r) => !r.pending || r.source).map((r) => `<div class="v2-led">
      <div class="v2-led-top"><b>${esc(String(r.league).toUpperCase())}</b><span class="m">${esc(r.source || "source pending")}${r.license ? ` · ${esc(r.license)}` : ""}</span></div>
      <div class="v2-led-nums"><span><b>${big(r.real_tokens)}</b> real</span><span><b>${big(r.synthetic_tokens)}</b> synthetic</span>
        <span><b>${big(r.windows)}</b> windows</span><span><b>${pct(r.crunch_share)}</b> crunch</span></div>
      ${r.seasons || r.games ? `<small>${esc(r.seasons || "")}${r.games ? ` · ${big(r.games)} games` : ""}${r.nights ? ` · ${big(r.nights)} nights` : ""}</small>` : ""}</div>`).join("");
  const ms = arr(nfm.milestones).map((m) => `<div class="v2-ms"><span class="tag tag--${MS_TAG[m.status] || "kind"}">${esc(m.status)}</span>
      <span>${esc(m.name)}${m.at ? ` <small>${esc(m.at)}</small>` : ""}${m.note ? `<small>${esc(m.note)}</small>` : ""}</span></div>`).join("");
  return `<h3>Data + NFM</h3>
    <p class="lead">${d.pending ? "Waiting on the first factory run: every number below is PENDING until lane 1 writes the ledger." : `Ledger updated ${esc(d.updated || "–")}.`}</p>
    <div class="v2-tiles"><div class="stile"><b>${big(t.real_tokens)}</b><span>Real tokens</span></div>
      <div class="stile"><b>${big(t.synthetic_tokens)}</b><span>Synthetic (self-play)</span></div>
      <div class="stile"><b>${typeof t.pct_of_target === "number" ? `${t.pct_of_target}%` : "–"}</b><span>of ${big(t.tokens_target)} target</span></div></div>
    <div class="v2-leds">${rows || `<p class="lead">No league has data yet.</p>`}</div>
    <h4>NFM milestones · ${num(nfm.done)}/${num(arr(nfm.milestones).length)} done</h4>
    <div class="v2-mss">${ms}</div>`;
}
ACTIONS["v2-ledger"] = async () => {
  ledgerS.data = null; openSheet({ id: "v2-ledger", label: "Data + NFM", full: true, render: ledgerSheet });
  try { ledgerS.data = await api("/api/v2/ledger"); } catch (e) { ledgerS.data = { error: e.message }; }
  const s = sheetById("v2-ledger"); if (s) s.update();
};

/* ---------- Slate preview: tonight ahead, crunch windows and who gets the TV when they collide ---------- */
const slate = { data: null };

async function loadSlate() {
  try { slate.data = await api("/api/v2/slate"); } catch (e) { slate.data = { error: e.message }; }
  const s = sheetById("v2-slate"); if (s) s.update();
}

function slateSheet() {
  const d = slate.data;
  if (!d) return `<h3>Tonight ahead</h3><p class="lead">Loading…</p>`;
  if (d.error) return `<h3>Tonight ahead</h3><p class="lead">${esc(d.error)}</p>`;
  const gs = arr(d.games);
  if (!gs.length) return `<h3>Tonight ahead</h3><p class="lead">No games live or still to come today.</p>`;
  const now = num(d.now);
  const a = Math.min(now, ...gs.map((g) => g.start)), b = Math.max(...gs.map((g) => g.end)), span = Math.max(60, b - a);
  const pct = (t) => (((t - a) / span) * 100).toFixed(2);
  const ticks = [];
  for (let t = Math.ceil(a / 3600) * 3600; t < b; t += 3600) ticks.push(`<i style="left:${pct(t)}%"><span>${esc(fmtTime(t).replace(":00", ""))}</span></i>`);
  const rows = gs.map((g) => `<div class="v2-g">
      <div class="v2-g-name ell">${g.yours ? icon("star", "ico--fill ico--xs") + " " : ""}${esc(g.matchup)} <small>${esc(String(g.league).toUpperCase())}${g.live ? " · live" : " · " + esc(fmtTime(g.start))}</small></div>
      <div class="v2-g-track"><b class="v2-g-bar ${g.yours ? "v2-g-bar--yours" : ""}" style="left:${pct(g.start)}%;width:${(((g.end - g.start) / span) * 100).toFixed(2)}%"></b>
        <b class="v2-g-crunch" style="left:${pct(g.crunch[0])}%;width:${(((g.crunch[1] - g.crunch[0]) / span) * 100).toFixed(2)}%" title="Crunch time"></b>
        <i class="v2-now" style="left:${pct(now)}%"></i></div></div>`).join("");
  const cl = arr(d.clashes);
  const clashes = cl.length ? cl.map((c) => `<div class="v2-ev"><span class="v2-ev-ic">${icon("swap")}</span><div style="min-width:0">
      <div class="v2-ev-top"><span class="m">${esc(c.on_tv)} on the TV</span><span class="t">${esc(fmtTime(c.t0))}–${esc(fmtTime(c.t1))}</span></div>
      <div class="v2-ev-why">${esc(arr(c.second).join(", "))} ${arr(c.second).length > 1 ? "wait" : "waits"} on the second stick, then catch-up (${esc(c.why)}).</div></div></div>`).join("")
    : `<div class="t2">No crunch times overlap tonight.</div>`;
  return `<h3>Tonight ahead</h3>
    <p class="lead">${gs.length} games, ${num(d.yours)} with your teams. Red = expected crunch time. Times are estimates from typical game lengths.</p>
    <div class="v2-gantt">${rows}<div class="v2-ticks">${ticks.join("")}</div></div>
    <div class="sheet-sec"><h4>When crunch times collide</h4><small>${cl.length}</small></div>
    <div class="v2-evs">${clashes}</div>`;
}

ACTIONS["v2-slate"] = () => { slate.data = null; openSheet({ id: "v2-slate", label: "Tonight ahead", full: true, render: slateSheet }); loadSlate(); };
/* ---------- Button states: what happened to the tap you just made (lane 3's id/ack/status API) ----------
   GO NOW / Watch this: "Switching to X…" until GET /api/action/{id} says the TV shows it ("On your TV"),
   or "Waiting for a safe moment" while it holds off mid-play. A tap whose answer was lost shows
   "Not delivered yet, retrying" while rz-api retries with the same id, then "Not delivered" if it gives up.
   A dropped live connection for 8 s shows a banner: taps may not reach the TV. Display only. */
const GAME_TAPS = new Set(["hold", "watch", "redzone", "focus"]);
const POLL_MS = 1000, POLL_FOR_MS = 25000;
const tap = { el: null, timer: null, hide: null };

function tapBar() {
  if (!tap.el) {
    tap.el = document.createElement("div");
    tap.el.className = "v2-tap";
    tap.el.setAttribute("role", "status");
    tap.el.setAttribute("aria-live", "polite");
    document.body.appendChild(tap.el);
  }
  return tap.el;
}

function showTap(kind, ic, text, ms = 0) {
  const el = tapBar();
  clearTimeout(tap.hide);
  el.dataset.kind = kind;
  el.innerHTML = `${icon(ic)}<span>${esc(text)}</span>`;
  el.hidden = false;
  if (ms) tap.hide = setTimeout(() => { el.hidden = true; }, ms);
}

function gameName(gid) {
  const g = arr(app.S && app.S.games).find((x) => x.id === gid);
  return (g && g.matchup) || "that game";
}

function follow(id, gid, t0 = Date.now()) {
  clearTimeout(tap.timer);
  tap.timer = setTimeout(async () => {
    let st = null;
    try { st = await api(`/api/action/${encodeURIComponent(id)}`); } catch { st = null; }
    if (st && st.on_tv) { showTap("ok", "check", `On your TV: ${gameName(gid)}`, 3000); return; }
    if (st && st.state === "failed") { showTap("bad", "alert", st.message || "That didn't work", 5000); return; }
    if (Date.now() - t0 > POLL_FOR_MS) { showTap("wait", "hourglass", `Still waiting for a safe moment in ${gameName(gid)}`, 6000); return; }
    follow(id, gid, t0);
  }, POLL_MS);
}

export function onTap(d) {
  if (!v2.on || !d) return;
  const action = d.body && d.body.action;
  if (d.phase === "retry") { showTap("wait", "wifi", `Not delivered yet, retrying (${d.attempt})…`); return; }
  if (d.phase === "lost") { showTap("bad", "alert", "Not delivered: the app didn't answer. Tap again.", 6000); return; }
  if (d.phase !== "answer" || !d.res) return;
  const r = d.res, gid = d.body.game_id;
  if (!GAME_TAPS.has(action) || !gid || r.ok === false) { if (tap.el && tap.el.dataset.kind === "wait") tap.el.hidden = true; return; }
  if (r.on_tv) { showTap("ok", "check", `On your TV: ${gameName(gid)}`, 3000); return; }
  showTap("wait", "swap", d.body.value === "force" ? `Switching to ${gameName(gid)} now…` : `Switching to ${gameName(gid)} at the next safe moment…`);
  follow(r.id || d.id, gid);
}
try { window.addEventListener("rz:tap", (e) => onTap(e.detail)); } catch { /* no window */ }

/* Stale connection: the #conn pill (app.js) says "Reconnecting" for 8 s -> one banner until it's back. */
const STALE_MS = 8000;
function watchConn() {
  const c = document.getElementById("conn");
  if (!c || typeof MutationObserver === "undefined") return;
  let since = null, t = null;
  const check = () => {
    const bad = c.dataset.state === "wait";
    clearTimeout(t);
    if (!bad) { since = null; if (tap.el && tap.el.dataset.kind === "stale") tap.el.hidden = true; return; }
    since = since || Date.now();
    t = setTimeout(() => { if (v2.on && c.dataset.state === "wait") showTap("stale", "wifi", "Lost the connection to the Mac. Taps may not reach the TV; reconnecting…"); }, Math.max(0, STALE_MS - (Date.now() - since)));
  };
  new MutationObserver(check).observe(c, { attributes: true, attributeFilter: ["data-state"] });
  check();
}
try { if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", watchConn); else watchConn(); } catch { /* no DOM */ }
