#!/usr/bin/env python3
"""World model pilot (EXP-100): event tokens -> a small transformer -> held-out-night grades, end to end.

    python scripts/world_model_pilot.py --out /content/wm [--leagues nfl,nba,mlb] [--minutes 60] [--smoke]

Serves: North Star "% of hindsight-oracle value achieved" (the world model the planner searches, master plan v2);
owner: lane 1 (Noggin training). Plumbing proof for Saturday's ~100M run (Nick, Nov 4 8:00 PM), not the product.

1. Data: public play-by-play from GitHub releases only (plan A: nflverse NFL 2001-24, NBA.com cdn NBA 2020-25, Retrosheet MLB 1974-2024; hoopR NBA = nba_espn, only
   with --allow-espn-derived; see
   docs/data-sources.md), tokenized by scripts/noggin_tokens.py (vocab v1: 6 tokens per event = kind, dt, clock,
   margin, points, stoppage; one BOS per game + both teams). The factory's EVAL_FIRST_NIGHT cut drops every game
   on or after the scorecard window, so no locked or scorecard night is ever downloaded or tokenized.
2. Split by whole night (time order): the last 10% of nights = test, the 10% before = valid, the rest = train.
3. Model: a decoder-only transformer (~25-30M params), next-token loss; the checkpoint is chosen on VALID only
   (early stop), with a checkpoint every 30 min.
4. Grades on the held-out test nights, each with a 95% game-bootstrap CI, beside count baselines fit on train:
   next-event kind accuracy (vs a bigram on the previous kind), next-stoppage calibration (ECE, Brier, vs the
   frequency after the previous kind) and break-timing MAE (the seconds from a break to the next event, vs the
   train median per stoppage type). Plus training/inference throughput (tokens/s) to size the 100M run.
Writes OUT/grades.json and prints it.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
import urllib.request
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

import noggin_tokens as T  # noqa: E402

SEED = 7
# NFL 2025 sits past the factory cut (scorecard + locked window), so it is never fetched
# Seasons by END year. nba = NBA.com cdn log (catalog yellow, OK; 2020-21 on); mlb = Retrosheet (green, no clocks);
# nba_espn = hoopR (ESPN-derived, gated below).
SEASONS = {"nba": list(range(2021, 2026)), "nba_espn": list(range(2019, 2027)), "nfl": list(range(2001, 2025)),
           "mlb": list(range(1974, 2025))}
# NFL 1999-2000 lack play wallclocks in nflverse (71% / 17% of gaps read 0 s, vs ~2.5% from 2003 on), so their
# time-to-next labels are wrong; they start in 2001 (3.7%).
# hoopR NBA is an ESPN-derived release: Wave 5, default OFF until Nick decides (docs/datasources/sources-catalog.md;
# Disney's terms bar AI training). It is read only with --allow-espn-derived.
ESPN_DERIVED = {"nba_espn"}
TOKEN_LEAGUE = {"nba_espn": "nba"}          # the vocab's league for each data key
BREAKS = ("timeout", "two_minute_warning", "end_period", "halftime", "intermission", "review", "injury",
          "pitching_change", "score_break")
# dt bucket b covers [2^(b/2.6) - 1, 2^((b+1)/2.6) - 1) seconds (noggin_tokens.dt_token); its midpoint in seconds
DT_MID = np.array([(2 ** (b / 2.6) - 1 + 2 ** ((b + 1) / 2.6) - 1) / 2 for b in range(T.DT_BUCKETS)])


# ---------------------------------------------------------------------------------------------- data
def fetch(league: str, year: int, raw: Path) -> Path | None:
    from redzone.noggin import factory as F
    if league == "nba":
        import nba_cdn_plays
        return nba_cdn_plays.fetch_season(year - 1, raw)          # cdn files are named by the start year
    if league == "mlb":
        import retrosheet_plays
        return retrosheet_plays.fetch_season(year, raw)
    url = F.SOURCES[TOKEN_LEAGUE.get(league, league)]["url"].format(y=year)
    dst = raw / league / f"{year}.parquet"
    if not dst.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        try:
            urllib.request.urlretrieve(url, dst.with_suffix(".tmp"))
        except Exception as e:  # noqa: BLE001 - a missing season is skipped, and the ledger says so
            print(f"{league} {year}: not downloaded ({type(e).__name__})", flush=True)
            return None
        os.replace(dst.with_suffix(".tmp"), dst)
    return dst


def v2_edges(lg: str, years: list[int], out: Path) -> dict | None:
    """Vocab v2 bucket edges for a league, fit once on its middle season (always a train season under split(): the
    last 20% of nights are valid + test), then shared by every season."""
    import noggin_tokens_v2 as V2
    p = out / "tokens_v2" / f"{lg}_edges.json"
    if p.exists():
        return json.loads(p.read_text())
    y = years[len(years) // 2]
    raw = fetch(lg, y, out / "raw")
    if raw is None:
        return None
    info = V2.build(TOKEN_LEAGUE.get(lg, lg), raw, y, out / "tokens_v2" / "fit" / lg)
    p.write_text(json.dumps(info["edges"]))
    return info["edges"]


def build_games(leagues, out: Path, smoke: bool, vocab: int = 1) -> list[dict]:
    """[{league, gid, night, tokens}] for every tokenized game (vocab 1: noggin_tokens; 2: noggin_tokens_v2)."""
    games = []
    for lg in leagues:
        years = SEASONS[lg][-1:] if smoke else SEASONS[lg]
        edges = v2_edges(lg, years, out) if vocab == 2 else None
        for y in years:
            raw = fetch(lg, y, out / "raw")
            if raw is None:
                continue
            tl = TOKEN_LEAGUE.get(lg, lg)
            if vocab == 2:
                import noggin_tokens_v2 as V2
                info = V2.build(tl, raw, y, out / "tokens" / lg, edges=edges)
            else:
                info = T.build(tl, raw, y, out / "tokens" / lg)
            arr = np.load(out / "tokens" / lg / tl / f"{y}.npy")
            for gid, night, off, n, _ in info["index"]:
                games.append({"league": lg, "gid": gid, "night": night, "tokens": arr[off:off + n]})
            print(f"{lg} {y}: {info['games']} games, {info['tokens']:,} tokens", flush=True)
            if smoke:                                     # a small slice of each league
                keep = [g for g in games if g["league"] != lg] + [g for g in games if g["league"] == lg][:120]
                games = keep
    return games


PERSONAL = "personal-use, not for commercial release"


def load_shards(root: Path, leagues) -> tuple[list[dict], set[str]]:
    """The factory's event-token shards (<root>/<league>/<year>.npy + .json), no download. Returns the games and the
    set of shard licenses (a restrictive-terms shard makes the model personal-use)."""
    games, lic = [], set()
    for lg in leagues:
        for js in sorted((root / lg).glob("*.json")):
            info = json.loads(js.read_text())
            if not info.get("complete") or not (js.with_suffix(".npy")).exists():
                continue
            arr = np.load(js.with_suffix(".npy"), mmap_mode="r")
            lic.add(info.get("license") or (PERSONAL if "espn" in str(info.get("source", "")).lower()
                                            or "hoopr" in str(info.get("source", "")).lower() else "open"))
            for gid, night, off, n, *_ in info["index"]:
                games.append({"league": lg, "gid": gid, "night": night, "tokens": np.asarray(arr[off:off + n])})
            print(f"{lg} {js.stem}: {info['games']} games, {info['tokens']:,} tokens ({info.get('source')})", flush=True)
    return games, lic


def split(games: list[dict]) -> dict[str, list[dict]]:
    """Time split by whole night, per league: each league's own last 10% of nights is test, the 10% before is valid.
    A pooled cut would put every test night in whichever league's data runs latest (NBA cdn ends 2025, Retrosheet
    2024), leaving that league with no train rows and the others with no test rows."""
    out = {"train": [], "valid": [], "test": []}
    for lg in sorted({g["league"] for g in games}):
        mine = [g for g in games if g["league"] == lg]
        nights = sorted({g["night"] for g in mine})
        n = len(nights)
        va0, te0 = nights[int(n * 0.8)], nights[int(n * 0.9)]
        for g in mine:
            out["test" if g["night"] >= te0 else "valid" if g["night"] >= va0 else "train"].append(g)
    return out


def valid_start(games: list[dict]) -> dict[str, str]:
    """Each league's first valid night under split(): extra (synthetic) games must sit strictly before it."""
    out = {}
    for lg in sorted({g["league"] for g in games}):
        nights = sorted({g["night"] for g in games if g["league"] == lg})
        out[lg] = nights[int(len(nights) * 0.8)]
    return out


SYNTH_CAP = 3.0                                         # Nick 11:50 PM: synthetic <= ~3x real, per league


def add_extra(train: list[dict], extra: list[dict], starts: dict[str, str]) -> tuple[list[dict], dict]:
    """Synthetic shards (EXP-1401 mirror / re-time) join TRAIN only: drop any game on or after its league's first
    valid night (or of a league with no real data), and refuse more than SYNTH_CAP x the league's real train tokens."""
    real = {lg: sum(len(g["tokens"]) for g in train if g["league"] == lg) for lg in starts}
    keep = [g for g in extra if g["league"] in starts and g["night"] < starts[g["league"]]]
    syn = {lg: sum(len(g["tokens"]) for g in keep if g["league"] == lg) for lg in starts}
    over = {lg: round(syn[lg] / max(1, real[lg]), 2) for lg in starts if syn[lg] > SYNTH_CAP * real[lg]}
    if over:
        raise SystemExit(f"synthetic > {SYNTH_CAP}x real train tokens: {over}")
    rep = {"games": len(keep), "dropped_not_before_valid": len(extra) - len(keep),
           "ratio_by_league": {lg: round(syn[lg] / max(1, real[lg]), 3) for lg in starts}}
    return train + [{**g, "synthetic": True} for g in keep], rep


def data_hash(games) -> str:
    h = hashlib.sha256()
    for g in sorted(games, key=lambda g: (g["league"], g["gid"])):
        h.update(g["gid"].encode())
        h.update(g["tokens"].tobytes())
    return h.hexdigest()[:16]


# ---------------------------------------------------------------------------------------------- model
def make_model(vocab: int, d: int, layers: int, heads: int, ctx: int, dropout: float = 0.0):
    import torch
    import torch.nn as nn

    class Block(nn.Module):
        def __init__(self):
            super().__init__()
            self.ln1, self.ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
            self.qkv, self.proj = nn.Linear(d, 3 * d), nn.Linear(d, d)
            self.mlp = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(), nn.Linear(4 * d, d), nn.Dropout(dropout))
            self.drop = nn.Dropout(dropout)

        def forward(self, x):
            b, t, _ = x.shape
            q, k, v = self.qkv(self.ln1(x)).view(b, t, 3, heads, d // heads).permute(2, 0, 3, 1, 4)
            a = torch.nn.functional.scaled_dot_product_attention(q, k, v, is_causal=True)
            x = x + self.drop(self.proj(a.transpose(1, 2).reshape(b, t, d)))
            return x + self.mlp(self.ln2(x))

    class WM(nn.Module):
        def __init__(self):
            super().__init__()
            self.tok, self.pos = nn.Embedding(vocab, d), nn.Embedding(ctx, d)
            self.blocks = nn.ModuleList(Block() for _ in range(layers))
            self.ln = nn.LayerNorm(d)
            self.head = nn.Linear(d, vocab, bias=False)
            self.head.weight = self.tok.weight          # tied
            self.apply(self._init)

        @staticmethod
        def _init(m):                                   # GPT-2 init: N(0, 0.02), zero bias
            if isinstance(m, (nn.Linear, nn.Embedding)):
                nn.init.normal_(m.weight, 0.0, 0.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.zeros_(m.bias)

        def forward(self, idx):
            x = self.tok(idx) + self.pos(torch.arange(idx.shape[1], device=idx.device))
            for blk in self.blocks:
                x = blk(x)
            return self.head(self.ln(x))

    return WM()


def cuts(t: np.ndarray, ctx: int) -> list[int]:
    """Window starts that tile the game exactly, each at an event's KIND token (or 0) and at most ctx apart. v1 events
    are 6 tokens; vocab v2 events carry a variable number of (FIELD VALUE) pairs, so cut on the KIND ids."""
    ev = np.flatnonzero((t >= T.KIND0) & (t < T.DT0))
    out, a = [0], 0
    while a + ctx < len(t) - 1:
        nxt = ev[(ev > a) & (ev <= a + ctx)]
        a = int(nxt[-1]) if len(nxt) else a + ctx      # a single event longer than ctx: hard cut
        out.append(a)
    return out


def windows(games, ctx: int, rng) -> np.ndarray:
    """Every game cut into ctx+1 windows on event boundaries (the same cut as grade())."""
    out = []
    for g in games:
        t = g["tokens"].astype(np.int64)
        for s in cuts(t, ctx):
            w = t[s:s + ctx + 1]
            if len(w) < 2:
                continue
            out.append(np.pad(w, (0, ctx + 1 - len(w)), constant_values=T.PAD))
    a = np.stack(out)
    rng.shuffle(a)
    return a


# ---------------------------------------------------------------------------------------------- grades
def positions(t: np.ndarray):
    """Indices (into a game's tokens) of each event's kind, dt and stop token (v1 and v2: the 6 v1 tokens lead)."""
    base = np.flatnonzero((t >= T.KIND0) & (t < T.DT0))
    base = base[base + 5 < len(t)]
    return base, base + 1, base + 5


def kind_of(tok: np.ndarray) -> np.ndarray:
    return tok.astype(np.int64)


def stop_name(tok: int) -> str:
    i = int(tok) - T.STOP0
    return T.STOPS[i] if 0 <= i < len(T.STOPS) else "unknown"


def baselines(train) -> dict:
    """Count models on train: next kind given the previous kind, P(stoppage) given the kind, break dt per stop."""
    from collections import Counter, defaultdict
    nxt, stop, dts = defaultdict(Counter), defaultdict(lambda: [0, 0]), defaultdict(list)
    for g in train:
        t = g["tokens"]
        k, dpos, s = positions(t)
        ks = t[k]
        for a, b in zip(ks[:-1], ks[1:]):
            nxt[int(a)][int(b)] += 1
        for kk, ss in zip(ks, t[s]):
            st = stop[int(kk)]
            st[0] += stop_name(ss) != "none"
            st[1] += 1
        for i in range(1, len(k)):
            nm = stop_name(t[s[i - 1]])
            if nm in BREAKS and t[dpos[i]] != T.UNK_DT:
                dts[nm].append(DT_MID[int(t[dpos[i]]) - T.DT0])
    prior = sum(v[0] for v in stop.values()) / max(1, sum(v[1] for v in stop.values()))
    return {"next": {a: c.most_common(1)[0][0] for a, c in nxt.items()},
            "p_stop": {a: (v[0] + prior) / (v[1] + 1) for a, v in stop.items()}, "p_prior": prior,
            "dt_med": {k: float(np.median(v)) for k, v in dts.items() if v}}


def ece(p, y, bins=10):
    p, y = np.asarray(p, float), np.asarray(y, float)
    if not len(p):
        return None
    idx = np.clip((p * bins).astype(int), 0, bins - 1)
    return float(sum(abs(p[idx == b].mean() - y[idx == b].mean()) * (idx == b).sum() for b in range(bins)
                     if (idx == b).any()) / len(p))


def boot(per_game: list[tuple], fn, n=300, seed=SEED):
    """95% CI of fn over games resampled with replacement (grading rule 4)."""
    if len(per_game) < 2:
        return None
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(n):
        pick = [per_game[i] for i in rng.integers(0, len(per_game), len(per_game))]
        v = fn(pick)
        if v is not None and math.isfinite(v):
            vals.append(v)
    return [round(float(np.percentile(vals, 2.5)), 4), round(float(np.percentile(vals, 97.5)), 4)] if vals else None


def grade_rows(model, games, base, ctx, dev, label: str = "", log_every: int = 200) -> list[dict]:
    """Per game: kind hits (model, bigram), stop probs (model, freq) + labels, break dt errors (model, median).
    Memory-flat: each window's logits are cut to the kind/stop/dt columns and moved to the CPU before the next
    window runs (EXP-103 run 1 died here holding whole-game float32 logits over the full vocab on the GPU)."""
    import torch
    rows = []
    model.eval()
    nk, ns, nd = T.DT0 - T.KIND0, len(T.STOPS), T.DT_BUCKETS
    cols = torch.cat([torch.arange(T.KIND0, T.DT0), torch.arange(T.STOP0, T.STOP0 + ns),
                      torch.arange(T.DT0, T.DT0 + nd)]).to(dev)
    none_i = T.STOPS.index("none")
    mid = torch.tensor(DT_MID, dtype=torch.float32)
    t0 = time.time()
    with torch.no_grad():
        for gi, g in enumerate(games):
            if log_every and gi and gi % log_every == 0:
                import resource
                mem = f", host peak {resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20:.1f} GB"
                mem += f", gpu {torch.cuda.memory_allocated() / 2**30:.1f} GB" if dev == "cuda" else ""
                print(f"  grade {label}: {gi}/{len(games)} games, {time.time() - t0:.0f} s{mem}", flush=True)
            t = g["tokens"].astype(np.int64)
            k, dpos, s = positions(t)
            if len(k) < 3:
                continue
            logits = []
            cs = cuts(t, ctx) + [len(t) - 1]
            for a, b in zip(cs[:-1], cs[1:]):           # windows that tile the game, on event boundaries
                x = torch.tensor(t[a:b], device=dev)[None]
                with torch.autocast(device_type=dev, dtype=torch.bfloat16, enabled=dev == "cuda"):
                    out = model(x)[0]
                logits.append(out[:, cols].float().cpu())
                del out
            lg = torch.cat(logits)                      # lg[i] predicts token i+1; columns kind | stop | dt
            r = {"league": g.get("league"), "night": g.get("night"),
                 "kind": [], "kind_b": [], "p": [], "p_b": [], "y": [], "dt": [], "dt_b": []}
            for i in range(1, len(k)):
                pk = T.KIND0 + int(lg[k[i] - 1, :nk].argmax())
                r["kind"].append(pk == t[k[i]])
                r["kind_b"].append(base["next"].get(int(t[k[i - 1]]), -1) == t[k[i]])
                ps = torch.softmax(lg[s[i] - 1, nk:nk + ns], 0)
                r["p"].append(float(1 - ps[none_i]))
                r["p_b"].append(base["p_stop"].get(int(t[k[i]]), base["p_prior"]))
                r["y"].append(stop_name(t[s[i]]) != "none")
                nm = stop_name(t[s[i - 1]])
                if nm in BREAKS and t[dpos[i]] != T.UNK_DT:
                    true = DT_MID[int(t[dpos[i]]) - T.DT0]
                    pd_ = torch.softmax(lg[dpos[i] - 1, nk + ns:], 0)
                    r["dt"].append(abs(float((pd_ * mid).sum()) - true))
                    r["dt_b"].append(abs(base["dt_med"].get(nm, true) - true))
            rows.append(r)
    if label:
        print(f"  grade {label}: done, {len(rows)} games, {time.time() - t0:.0f} s", flush=True)
    return rows


def summarize(rows: list[dict]) -> dict:
    cat = lambda pick, key: [v for r in pick for v in r[key]]   # noqa: E731
    mean = lambda pick, key: float(np.mean(cat(pick, key))) if cat(pick, key) else None   # noqa: E731
    out = {}
    for name, key in (("next_kind_acc", "kind"), ("next_kind_acc_bigram", "kind_b"),
                      ("break_dt_mae_s", "dt"), ("break_dt_mae_s_baseline", "dt_b")):
        out[name] = {"value": None if mean(rows, key) is None else round(mean(rows, key), 4),
                     "ci95": boot(rows, lambda p, key=key: mean(p, key)), "n": len(cat(rows, key))}
    for name, key in (("stop_ece", "p"), ("stop_ece_baseline", "p_b")):
        out[name] = {"value": None if not cat(rows, key) else round(ece(cat(rows, key), cat(rows, "y")), 4),
                     "ci95": boot(rows, lambda p, key=key: ece(cat(p, key), cat(p, "y")))}
    y = np.array(cat(rows, "y"), float)
    for name, key in (("stop_brier", "p"), ("stop_brier_baseline", "p_b")):
        out[name] = round(float(np.mean((np.array(cat(rows, key)) - y) ** 2)), 4) if len(y) else None
    out["games"] = len(rows)
    return out


def grade(model, games, base, ctx, dev, label: str = "") -> dict:
    return summarize(grade_rows(model, games, base, ctx, dev, label))


# ---------------------------------------------------------------------------------------------- train
def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--leagues", default="nfl,nba,mlb", help="plan A default; add nba_espn only with Nick's yes")
    ap.add_argument("--allow-espn-derived", action="store_true", help="only once Nick says yes (Wave 5)")
    ap.add_argument("--minutes", type=float, default=60.0, help="training wall-clock budget")
    ap.add_argument("--eval-mem-frac", type=float, default=0.85,
                    help="cap this process's GPU memory while grading (fraction of the card; 0 = no cap)")
    ap.add_argument("--grade-device", default="auto", choices=("auto", "cpu"),
                    help="cpu = grade on the CPU (slow, but no GPU memory at all)")
    ap.add_argument("--stop-before-grade", action="store_true",
                    help="train, save best.pt + trained.json, exit; a second run (same --out) grades only")
    ap.add_argument("--exp", default="EXP-100", help="experiments.md id written to grades.json")
    ap.add_argument("--d", type=int, default=512)
    ap.add_argument("--layers", type=int, default=8)
    ap.add_argument("--heads", type=int, default=8)
    ap.add_argument("--ctx", type=int, default=1020)          # 170 events
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--lr", type=float, default=6e-4)
    ap.add_argument("--dropout", type=float, default=0.1)
    ap.add_argument("--weight-decay", type=float, default=0.1)
    ap.add_argument("--smoke", action="store_true", help="CPU test: one season, a tiny model, a few steps")
    ap.add_argument("--from-tokens", type=Path, default=None,
                    help="train on the factory's token shards (<dir>/<league>/<year>.npy) instead of fetching")
    ap.add_argument("--vocab", type=int, default=1, choices=(1, 2), help="2 = rich tokens (noggin_tokens_v2)")
    ap.add_argument("--extra-shards", type=Path, default=None,
                    help="synthetic token shards (synth_build.py augment, EXP-1401): train only, before valid, <=3x")
    a = ap.parse_args(argv)
    if a.smoke:
        a.d, a.layers, a.heads, a.ctx, a.batch, a.minutes = 64, 2, 2, 120, 8, 0.3
    t_all = time.time()
    rng = np.random.default_rng(SEED)
    blocked = ESPN_DERIVED & set(a.leagues.split(",")) if not a.allow_espn_derived else set()
    if blocked:   # before torch, so the guard holds (and is tested) on a machine without it
        raise SystemExit(f"{sorted(blocked)}: ESPN-derived release; pass --allow-espn-derived (plan B, personal use)")
    import torch
    torch.manual_seed(SEED)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    a.out.mkdir(parents=True, exist_ok=True)
    if a.from_tokens:
        games, licenses = load_shards(a.from_tokens, a.leagues.split(","))
    else:
        games = build_games(a.leagues.split(","), a.out, a.smoke, a.vocab)
        licenses = {PERSONAL} if ESPN_DERIVED & set(a.leagues.split(",")) else {"open"}
        for js in (a.out / "tokens").rglob("*.json") if a.vocab == 2 else ():   # v2 shards carry their own license
            licenses.add(json.loads(js.read_text()).get("license", "open"))
    sp = split(games)
    starts = valid_start(games)
    print("first valid night:", json.dumps(starts), flush=True)
    extra_rep = None
    if a.extra_shards:
        extra, xlic = load_shards(a.extra_shards, a.leagues.split(","))
        licenses |= xlic
        sp["train"], extra_rep = add_extra(sp["train"], extra, starts)
        print("extra:", json.dumps(extra_rep), flush=True)
    counts = {k: {"games": len(v), "tokens": int(sum(len(g["tokens"]) for g in v)),
                  "nights": len({g["night"] for g in v}),
                  "first": min((g["night"] for g in v), default=None), "last": max((g["night"] for g in v), default=None)}
              for k, v in sp.items()}
    print("split:", json.dumps(counts), flush=True)
    vocab = max(T.VOCAB_SIZE, 1 + max(int(g["tokens"].max()) for g in games if len(g["tokens"])))  # v2 > v1
    model = make_model(vocab, a.d, a.layers, a.heads, a.ctx, a.dropout).to(dev)
    n_params = sum(p.numel() for p in model.parameters())
    print(f"model: {n_params / 1e6:.1f}M params on {dev}", flush=True)
    tr = windows(sp["train"], a.ctx, rng)
    va = windows(sp["valid"], a.ctx, rng)[:256]
    n_tr, train_dev = len(tr), dev
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.95), weight_decay=a.weight_decay)
    est_steps = max(50, int(a.minutes * 60 * 2))            # refined after the first 20 steps
    amp = dict(device_type=dev, dtype=torch.bfloat16, enabled=dev == "cuda")
    loss_fn = torch.nn.CrossEntropyLoss(ignore_index=T.PAD)

    def lr_at(s):
        return a.lr * min(1.0, (s + 1) / 100) * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * min(1.0, s / est_steps))))

    def val_loss():
        model.eval()
        tot, n = 0.0, 0
        with torch.no_grad(), torch.autocast(**amp):
            for i in range(0, len(va), a.batch):
                x = torch.tensor(va[i:i + a.batch], device=dev)
                tot += float(loss_fn(model(x[:, :-1]).float().reshape(-1, vocab), x[:, 1:].reshape(-1)))
                n += 1
        model.train()
        return round(tot / max(1, n), 4)

    ck, best_path = a.out / "ckpt.pt", a.out / "best.pt"
    step, ep, best, curve, last_ck, bad = 0, 0, float("inf"), [], time.time(), 0
    if ck.exists():                                        # resume (rerun on the same runtime)
        st = torch.load(ck, map_location=dev, weights_only=False)
        model.load_state_dict(st["model"])
        opt.load_state_dict(st["opt"])
        step, ep, best, curve = st["step"], st["ep"], st["best"], st["curve"]
        print(f"resumed at step {step}", flush=True)
    t0, toks, stop = time.time(), 0, False
    marker = a.out / "trained.json"              # training finished: a rerun goes straight to grading
    if marker.exists() and best_path.exists():
        m = json.loads(marker.read_text())
        step, ep, best, curve = m["step"], m["ep"], m["best"], m["curve"]
        toks, prev_train_s = m["toks"], m["train_s"]
        stop = True
        print(f"trained.json found (step {step}, best valid {best}): grading only", flush=True)
    model.train()
    while not stop:
        for i in range(0, len(tr) - a.batch + 1, a.batch):
            x = torch.tensor(tr[i:i + a.batch], device=dev)
            for gr in opt.param_groups:
                gr["lr"] = lr_at(step)
            with torch.autocast(**amp):
                loss = loss_fn(model(x[:, :-1]).float().reshape(-1, vocab), x[:, 1:].reshape(-1))
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            step += 1
            toks += x[:, :-1].numel()
            if step == 20:
                el = time.time() - t0
                est_steps = max(50, int(a.minutes * 60 / (el / 20)))
                print(f"{toks / el:,.0f} train tokens/s -> ~{est_steps} steps in {a.minutes:.0f} min", flush=True)
            if step % 100 == 0 or a.smoke and step % 10 == 0:
                v = val_loss()
                curve.append({"step": step, "epoch": ep, "train_loss": round(loss.item(), 4), "valid_loss": v})
                print(curve[-1], flush=True)
                if v < best:
                    best, bad = v, 0
                    torch.save(model.state_dict(), best_path)
                else:
                    bad += 1
                if bad >= 5:                                # early stop on valid
                    print("early stop on valid", flush=True)
                    stop = True
                    break
            if time.time() - last_ck > 1800:
                torch.save({"model": model.state_dict(), "opt": opt.state_dict(), "step": step, "ep": ep,
                            "best": best, "curve": curve}, ck)
                last_ck = time.time()
            if time.time() - t0 > a.minutes * 60 or step >= est_steps:
                stop = True
                break
        ep += 1
    if not marker.exists():
        train_s = time.time() - t0
        v = val_loss()
        curve.append({"step": step, "epoch": ep, "train_loss": round(loss.item(), 4), "valid_loss": v})
        if v < best or not best_path.exists():
            torch.save(model.state_dict(), best_path)
        best = min(best, v)
        marker.write_text(json.dumps({"step": step, "ep": ep, "best": best, "curve": curve, "toks": toks,
                                      "train_s": train_s}))
        print(f"saved {best_path} and {marker} before grading", flush=True)
    else:
        train_s = prev_train_s
    if a.stop_before_grade:
        return 0
    del opt, tr                                                             # free training state before grading
    import gc
    gc.collect()
    if dev == "cuda":
        torch.cuda.empty_cache()
    if a.grade_device == "cpu":
        dev = "cpu"
        model = model.to("cpu")
    elif dev == "cuda" and a.eval_mem_frac:
        torch.cuda.set_per_process_memory_fraction(a.eval_mem_frac)
    model.load_state_dict(torch.load(best_path, map_location=dev))         # chosen on VALID
    ti = time.time()
    base = baselines(sp["train"])
    partial = {"exp": a.exp, "partial": True, "best_valid_loss": best, "learning_curve": curve}

    def checkpoint_grades(key, val):                # grades.json grows as each section lands (a crash keeps them)
        partial[key] = val
        (a.out / "grades.json").write_text(json.dumps(partial, indent=1))
        print(f"grades.json: {key} written", flush=True)

    test_rows = grade_rows(model, sp["test"], base, a.ctx, dev, "test")
    test = summarize(test_rows)
    inf_toks = sum(len(g["tokens"]) for g in sp["test"])
    inf_s = time.time() - ti
    checkpoint_grades("test", test)
    keys = ("next_kind_acc", "next_kind_acc_bigram", "break_dt_mae_s", "break_dt_mae_s_baseline", "stop_ece",
            "stop_ece_baseline", "games")
    per_league = {lg: {k: summarize([r for r in test_rows if r["league"] == lg])[k] for k in keys}
                  for lg in sorted({r["league"] for r in test_rows})}
    checkpoint_grades("test_by_league", per_league)
    seasons = sorted({r["night"][:4] for r in test_rows})
    per_season = {y: {k: summarize([r for r in test_rows if r["night"][:4] == y])[k] for k in keys[:4]}
                  for y in seasons}
    checkpoint_grades("test_by_year", per_season)
    # The gap, split so overfitting and a season shift can be told apart (pilot 1: the train slice was the
    # EARLIEST 200 games, 2001, vs test 2022-24): train games nearest the test window vs the earliest, valid,
    # and test per season.
    by_t = sorted(sp["train"], key=lambda g: g["night"])
    trn = grade(model, by_t[-200:], base, a.ctx, dev, "train_recent")
    trn_old = grade(model, by_t[:200], base, a.ctx, dev, "train_earliest")
    val = grade(model, sp["valid"], base, a.ctx, dev, "valid")
    g = {"exp": a.exp, "seed": SEED,
         "license": PERSONAL if any(x != "open" and not x.startswith("open") for x in licenses) else "open", "data_sha256_16": data_hash(games), "vocab": 2 if vocab > T.VOCAB_SIZE else T.VOCAB_VERSION,
         "vocab_size": vocab, "leagues": a.leagues, "split": counts,
         "valid_first_night": starts, "extra_shards": extra_rep, "selection": "valid loss (early stop)",
         "recipe": {"d": a.d, "layers": a.layers, "heads": a.heads, "ctx": a.ctx, "batch": a.batch, "lr": a.lr, "dropout": a.dropout, "weight_decay": a.weight_decay,
                    "params_m": round(n_params / 1e6, 1), "steps": step, "epochs_seen": round(step * a.batch / max(1, n_tr), 2)},
         "learning_curve": curve, "best_valid_loss": best,
         "test": test, "test_by_league": per_league, "train_slice": {k: trn[k] for k in ("next_kind_acc", "stop_ece", "break_dt_mae_s")},
         "gap": {"train_recent_200": {k: trn[k] for k in ("next_kind_acc", "break_dt_mae_s", "break_dt_mae_s_baseline")},
                 "train_earliest_200": {k: trn_old[k] for k in ("next_kind_acc", "break_dt_mae_s",
                                                                "break_dt_mae_s_baseline")},
                 "valid": {k: val[k] for k in ("next_kind_acc", "break_dt_mae_s", "break_dt_mae_s_baseline")},
                 "test_by_year": per_season},
         "throughput": {"device": torch.cuda.get_device_name(0) if train_dev == "cuda" else "cpu",
                        "grade_device": dev,
                        "train_tokens_per_s": round(toks / max(1e-9, train_s)),
                        "eval_tokens_per_s": round(inf_toks / max(1e-9, inf_s)),
                        "train_s": round(train_s), "total_s": round(time.time() - t_all)},
         "locked": "never downloaded (factory EVAL_FIRST_NIGHT cut); test = the last 10% of pre-cut nights"}
    tp = g["throughput"]["train_tokens_per_s"]
    g["sizing_100m"] = {"tokens_per_s_scaled": round(tp * n_params / 100e6),
                        "hours_per_1b_tokens": round(1e9 / max(1, tp * n_params / 100e6) / 3600, 2)}
    (a.out / "grades.json").write_text(json.dumps(g, indent=1))
    print("===== grades.json =====")
    print(json.dumps(g, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
